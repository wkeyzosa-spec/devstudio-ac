sha256 = {}

local MOD = 2^32
local MODM = MOD - 1

local function memoize(f)
    local mt = {}
    local t = setmetatable({}, {__index = mt})
    return function(x)
        local v = mt[x]
        if v == nil then
            v = f(x)
            mt[x] = v
        end
        return v
    end
end

local function _rrot(x, n)
    return ((x >> n) | (x << (32 - n))) & MODM
end

local function _hrot(x, n)
    return (x >> n) | (x << (32 - n))
end

local _K = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
}

local function _ch(x, y, z)
    return (x & y) | (~x & z)
end

local function _maj(x, y, z)
    return (x & y) | (x & z) | (y & z)
end

local function _sigma0(x)
    return _rrot(x, 2) ~ _rrot(x, 13) ~ _rrot(x, 22)
end

local function _sigma1(x)
    return _rrot(x, 6) ~ _rrot(x, 11) ~ _rrot(x, 25)
end

local function _gamma0(x)
    return _rrot(x, 7) ~ _rrot(x, 18) ~ (x >> 3)
end

local function _gamma1(x)
    return _rrot(x, 17) ~ _rrot(x, 19) ~ (x >> 10)
end

local function _tohex(x)
    local t = {}
    for i = 1, 32 do
        t[33 - i] = string.char(48 + (x & 1) + 39 * ((x & 1) >> 3))
        x = x >> 1
    end
    return table.concat(t):gsub('[^0-9a-fA-F]', function(c)
        return string.format('%x', 10 + (string.byte(c) % 7))
    end)
end

function sha256.sha256(msg)
    local H = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    }

    local msg_len = #msg
    local msg_bits = msg_len * 8

    local padded = {string.byte(msg, 1, msg_len)}
    table.insert(padded, 0x80)

    while (#padded + 8) % 64 ~= 0 do
        table.insert(padded, 0)
    end

    for i = 56, 0, -1 do
        table.insert(padded, (msg_bits >> (i * 8)) & 0xff)
    end

    for i = 1, #padded, 64 do
        local W = {}
        for t = 1, 16 do
            W[t] = (padded[i + (t - 1) * 4] << 24) |
                   (padded[i + (t - 1) * 4 + 1] << 16) |
                   (padded[i + (t - 1) * 4 + 2] << 8) |
                   (padded[i + (t - 1) * 4 + 3])
        end
        for t = 17, 64 do
            W[t] = (_gamma1(W[t - 2]) + W[t - 7] + _gamma0(W[t - 15]) + W[t - 16]) & MODM
        end

        local a, b, c, d, e, f, g, h = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]

        for t = 1, 64 do
            local T1 = (h + _sigma1(e) + _ch(e, f, g) + _K[t] + W[t]) & MODM
            local T2 = (_sigma0(a) + _maj(a, b, c)) & MODM
            h = g
            g = f
            f = e
            e = (d + T1) & MODM
            d = c
            c = b
            b = a
            a = (T1 + T2) & MODM
        end

        H[1] = (H[1] + a) & MODM
        H[2] = (H[2] + b) & MODM
        H[3] = (H[3] + c) & MODM
        H[4] = (H[4] + d) & MODM
        H[5] = (H[5] + e) & MODM
        H[6] = (H[6] + f) & MODM
        H[7] = (H[7] + g) & MODM
        H[8] = (H[8] + h) & MODM
    end

    return string.format("%08x%08x%08x%08x%08x%08x%08x%08x",
        H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8])
end

function sha256.hmac(key, msg)
    local block_size = 64

    if #key > block_size then
        key = sha256.sha256(key)
        key = (string.rep("\0", block_size - #key) .. key):sub(1, block_size)
    elseif #key < block_size then
        key = key .. string.rep("\0", block_size - #key)
    end

    local o_key_pad = ""
    local i_key_pad = ""

    for i = 1, block_size do
        local k = string.byte(key, i)
        o_key_pad = o_key_pad .. string.char(0x5c ~ k)
        i_key_pad = i_key_pad .. string.char(0x36 ~ k)
    end

    return sha256.sha256(o_key_pad .. sha256.sha256(i_key_pad .. msg))
end
