fx_version 'bodacious'
games { 'gta5' }

author 'Dev Studio'
description "Dev Studio AC - Advanced Anticheat"

shared_script 'config.lua'
shared_script 'sha256.lua'

client_scripts {
    'Enumerators.lua',
    'client.lua', 
    'acloader.lua'
}

server_scripts {
    'server.lua',
}