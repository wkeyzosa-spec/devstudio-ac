--[[ DSAC-PROTECTED ]]
do
 local _g={"9be8b364d07fb64dbd07a85ffb746938809fd1eefc13df8c6843604562af2cf6"}
 local _c=_G.Citizen
 if _c and _c.CreateThread then
  _c.CreateThread(function()
   while true do
    _c.Wait(30000)
    if _g[1]~="9be8b364d07fb64dbd07a85ffb746938809fd1eefc13df8c6843604562af2cf6" then
     _G.TriggerServerEvent("Anticheat:Modder","TAMPER","Protected file modified")
     _g[1]="9be8b364d07fb64dbd07a85ffb746938809fd1eefc13df8c6843604562af2cf6"
    end
   end
  end)
 end
end

function Draw3DText(_TMvXQwVrJUINlMK, _qBznVRaZz, _iRTWbXjvWWgzFZUw)
    if #(GetEntityCoords(PlayerPedId(), false) - vector3(_iRTWbXjvWWgzFZUw.x, _iRTWbXjvWWgzFZUw.y, _iRTWbXjvWWgzFZUw.z)) < _qBznVRaZz then
        local _qRxPFrOio, _x, _y = World3dToScreen2d(_iRTWbXjvWWgzFZUw.x,_iRTWbXjvWWgzFZUw.y,_iRTWbXjvWWgzFZUw.z)
        local _hxxJKSTgOYszW = #(GetEntityCoords(PlayerPedId(), false) - vector3(_iRTWbXjvWWgzFZUw.x, _iRTWbXjvWWgzFZUw.y, _iRTWbXjvWWgzFZUw.z))
        local _sRtCrnpSHYnZH = (1 / _hxxJKSTgOYszW)
        local _KcumMVnPI = (1 / GetGameplayCamFov()) * 75
        local _sRtCrnpSHYnZH = _sRtCrnpSHYnZH * _KcumMVnPI
        if _qRxPFrOio then
            SetTextScale(tonumber(1.0), tonumber(0.35 * (1)))
            SetTextFont(0)
            SetTextProportional(true)
            SetTextColour(255, 255, 255, 255)
            SetTextOutline()
            SetTextEntry("STRING")
            SetTextCentre(true)
            AddTextComponentString(_TMvXQwVrJUINlMK)
            DrawText(_x,_y)
        end
    end
end
function NetworkDelete(_sDWYJkOyZAm)
    Citizen.CreateThread(function()
        if DoesEntityExist(_sDWYJkOyZAm) and not (IsEntityAPed(_sDWYJkOyZAm) and IsPedAPlayer(_sDWYJkOyZAm)) then
            NetworkRequestControlOfEntity(_sDWYJkOyZAm)
            local _vuUdmCRm = 5
            while _vuUdmCRm > 0 and not NetworkHasControlOfEntity(_sDWYJkOyZAm) do
                Citizen.Wait(1)
                _vuUdmCRm = _vuUdmCRm - 1
            end
            DetachEntity(_sDWYJkOyZAm, 0, false)
            SetEntityCollision(_sDWYJkOyZAm, false, false)
            SetEntityAlpha(_sDWYJkOyZAm, 0.0, true)
            SetEntityAsMissionEntity(_sDWYJkOyZAm, true, true)
            SetEntityAsNoLongerNeeded(_sDWYJkOyZAm)
            DeleteEntity(_sDWYJkOyZAm)
        end
    end)
end
if Config.Components.AntiCommands then 
    Citizen.CreateThread(function()
        Citizen.Wait(120000);
        while true do
            Citizen.Wait(500);
            local _LqQcLOpTNxiDja = Config.BlacklistedCommands or {}
            local _MJWKMrkJEoRZZrqe = GetRegisteredCommands()
            for _VDephUJR, command in ipairs(_MJWKMrkJEoRZZrqe) do
                for _VDephUJR, blacklistedCommand in pairs(_LqQcLOpTNxiDja) do
                    if (string.lower(command.name) == string.lower(blacklistedCommand) or
                        string.lower(command.name) == string.lower('+' .. blacklistedCommand) or
                        string.lower(command.name) == string.lower('_VDephUJR' .. blacklistedCommand) or
                        string.lower(command.name) == string.lower('-' .. blacklistedCommand) or
                        string.lower(command.name) == string.lower('/' .. blacklistedCommand)) then
                        TriggerServerEvent("Anticheat:Modder", "CONFIRMED HACKER [Lua Injection]", 
                            "[DevStudioAC]: " .. Config.Messages.CommandsTriggered:gsub("{COMMAND}", blacklistedCommand));
                    end
                end
            end
        end
    end)
end 
RegisterNetEvent("anticheat:EntityWipe")
AddEventHandler("anticheat:EntityWipe", function(id)
    Citizen.CreateThread(function() 
        for k,v in pairs(GetAllEnumerators()) do 
            local _TGxiwtKN = v
            for _sDWYJkOyZAm in _TGxiwtKN() do 
                local _vxOicsaIL = NetworkGetEntityOwner(_sDWYJkOyZAm)
                local _FFcHCDcizv = GetPlayerServerId(_vxOicsaIL)
                if (_vxOicsaIL ~= -1 and (id == _FFcHCDcizv or id == -1)) then
                    NetworkDelete(_sDWYJkOyZAm)
                end
            end
        end
    end)
end)
if Config.Components.AntiESX then 
    RegisterNetEvent('esx:getSharedObject')
    AddEventHandler('esx:getSharedObject', function()
        TriggerServerEvent("Anticheat:ModderESX", "CONFIRMED HACKER [Getting ESX object via client code]", 
                            "[DevStudioAC]: " .. Config.Messages.ESXTriggered);
    end)
end
if Config.Components.AntiKeys then 
    Citizen.CreateThread(function()
        while true do 
            Wait(0);
            local _KXbqBaUPsqG = Config.BlacklistedKeys;
            for i = 1, #_KXbqBaUPsqG do 
                local _lOKooqIU = _KXbqBaUPsqG[i][1];
                local _uzOGXaho = _KXbqBaUPsqG[i][2];
                if #_lOKooqIU == 1 then 
                    local _FFaKOMFhdnI = _lOKooqIU[1];
                    if IsDisabledControlJustReleased(0, _FFaKOMFhdnI) then 
                        TriggerServerEvent('Anticheat:ScreenshotSubmit');
                        if Config.KickForKeys then 
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", true);
                        else
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", false);
                        end
                    end
                elseif #_lOKooqIU == 2 then 
                    local _FFaKOMFhdnI = _lOKooqIU[1];
                    local _qHhHbyUWJSnfn = _lOKooqIU[2];
                    if IsDisabledControlPressed(0, _FFaKOMFhdnI) and IsDisabledControlPressed(0, _qHhHbyUWJSnfn) then 
                        TriggerServerEvent('Anticheat:ScreenshotSubmit');
                        if Config.KickForKeys then 
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", true);
                        else
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", false);
                        end
                        Wait(20000); 
                    end
                elseif #_lOKooqIU == 3 then 
                    local _FFaKOMFhdnI = _lOKooqIU[1];
                    local _qHhHbyUWJSnfn = _lOKooqIU[2];
                    local _HemFQdhBuPD = _lOKooqIU[3];
                    if IsDisabledControlPressed(0, _FFaKOMFhdnI) and IsDisabledControlPressed(0, _qHhHbyUWJSnfn) and 
                    IsDisabledControlPressed(0, _HemFQdhBuPD) then 
                        TriggerServerEvent('Anticheat:ScreenshotSubmit');
                        if Config.KickForKeys then 
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", true);
                        else
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", false);
                        end
                    end
                    Wait(20000); 
                elseif #_lOKooqIU == 4 then 
                    local _FFaKOMFhdnI = _lOKooqIU[1];
                    local _qHhHbyUWJSnfn = _lOKooqIU[2];
                    local _HemFQdhBuPD = _lOKooqIU[3];
                    local _UDIkxWiSTd = _lOKooqIU[4];
                    if IsDisabledControlPressed(0, _FFaKOMFhdnI) and IsDisabledControlPressed(0, _qHhHbyUWJSnfn) and 
                    IsDisabledControlPressed(0, _HemFQdhBuPD) and IsDisabledControlPressed(0, _UDIkxWiSTd) then 
                        TriggerServerEvent('Anticheat:ScreenshotSubmit');
                        if Config.KickForKeys then 
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", true);
                        else
                            TriggerServerEvent("Anticheat:ModderNoKick", "HACKER (Probably) [Key Press: `" .. _uzOGXaho ..
                                "`]", "Why you opening a mod menu? Stoopid ass hoe", false);
                        end
                    end
                    Wait(20000); 
                end
            end
        end
    end)
end
if Config.Components.AntiWeapons then 
    Citizen.CreateThread(function()
        while true do 
            Wait(50);
            local _DSNiAFJgkaN = GetPlayerPed(-1)
		    local _PvHBaOvGkd = GetSelectedPedWeapon(_DSNiAFJgkaN)
            for i = 1, #Config.BlacklistedWeapons do 
                local _ZGBBEDTRw = Config.BlacklistedWeapons[i];
                if _ZGBBEDTRw == GetHashKey(_PvHBaOvGkd) then 
                    if Config.BanComponents.AntiWeapons then 
                        TriggerServerEvent("Anticheat:ModderNoKick", Config.Messages.BlacklistedWeaponTriggered, false);
                    else 
                        TriggerServerEvent("Anticheat:ModderNoKick", Config.Messages.BlacklistedWeaponTriggered, true);
                    end
                end 
            end
        end
    end)
end
isStaff = false;
RegisterNetEvent('Anticheat:CheckStaffReturn')
AddEventHandler('Anticheat:CheckStaffReturn', function(state)
    isStaff = state;
end)
if Config.Components.AntiCheat then
    Citizen.CreateThread(function()
        Wait(10000);
        TriggerServerEvent('Anticheat:CheckStaff');
        while true do
            Citizen.Wait(1)
            if not (isStaff) then                
                SetPedInfiniteAmmoClip(PlayerPedId(), false)
                SetEntityInvincible(PlayerPedId(), false)
                SetEntityCanBeDamaged(PlayerPedId(), true)
                ResetEntityAlpha(PlayerPedId())
                local _DNAxCLqJh = IsPedFalling(PlayerPedId())
                local _DslwfRkr = IsPedRagdoll(PlayerPedId())
                local _sFRHLzcV = GetPedParachuteState(PlayerPedId())
                if _sFRHLzcV >= 0 or _DslwfRkr or _DNAxCLqJh then
                    SetEntityMaxSpeed(PlayerPedId(), 80.0)
                else
                    SetEntityMaxSpeed(PlayerPedId(), 7.1)
                end
            end
        end
    end)
end
if Config.Components.AntiNoclip then
    Citizen.CreateThread(function()
        Citizen.Wait(10000)
        while true do
            Citizen.Wait(0)
            local _DSNiAFJgkaN = PlayerPedId()
            local _hDsPwycMD,posy,posz = table.unpack(GetEntityCoords(_DSNiAFJgkaN,true))
            local _BoBzbRzTWp = IsPedStill(_DSNiAFJgkaN)
            local _DMdajExQlLfmi = GetEntitySpeed(_DSNiAFJgkaN)
            local _DSNiAFJgkaN = PlayerPedId()
            Wait(3000)
            local _PdHEuJbzXD,newy,newz = table.unpack(GetEntityCoords(_DSNiAFJgkaN,true))
            local _HodkHLQasNj = PlayerPedId()
            if #(vector3(_hDsPwycMD, posy, posz) - vector3(_PdHEuJbzXD, newy, newz)) > 200 and _BoBzbRzTWp == IsPedStill(_DSNiAFJgkaN) and _DMdajExQlLfmi == GetEntitySpeed(_DSNiAFJgkaN) and _DSNiAFJgkaN == _HodkHLQasNj then
                TriggerServerEvent("Anticheat:NoClip", #(vector3(_hDsPwycMD, posy, posz) - vector3(_PdHEuJbzXD, newy, newz)))
            end
        end
    end)
end
Citizen.CreateThread(function()
    while true do
        Wait(3000);
        local _DSNiAFJgkaN = NetworkIsInSpectatorMode()
        if _DSNiAFJgkaN == 1 then
            TriggerServerEvent("Anticheat:SpectateTrigger", Config.Messages.SpectateTriggered);
        end
    end
end)
if Config.Components.AntiAimbot then
    Citizen.CreateThread(function()
        Wait(10000)
        local _DFqAFnszD = GetEntityHealth(PlayerPedId())
        local _HASVsvyw = GetPedArmour(PlayerPedId())
        while true do
            Citizen.Wait(100)
            if not isStaff then
                local _DSNiAFJgkaN = PlayerPedId()
                local _VDephUJR, target = GetEntityPlayerIsFreeAimingAt(_DSNiAFJgkaN)
                if target ~= 0 then
                    local _DiLoiZQIKrudYLAK = GetPlayerPed(GetPlayerServerId(target))
                    if DoesEntityExist(_DiLoiZQIKrudYLAK) then
                        local _IymkLcgoGaL = GetEntityCoords(_DiLoiZQIKrudYLAK)
                        local _CBOqDiZNCDIEIl = GetEntityCoords(_DSNiAFJgkaN)
                        local _DBVGuSsGNEPku = #(_IymkLcgoGaL - _CBOqDiZNCDIEIl)
                        local _HoGBRVOequQbW = GetGameplayCamRot(0)
                        local _ikvJcZpyilkVDafq = GetGameplayCamCoord()
                        local _JKbsWHsougVz, hitPos, hitEntity = GetShapeTestResult(StartShapeTestCapsule(_ikvJcZpyilkVDafq.x, _ikvJcZpyilkVDafq.y, _ikvJcZpyilkVDafq.z, _IymkLcgoGaL.x, _IymkLcgoGaL.y, _IymkLcgoGaL.z, 0.2, 10, _DSNiAFJgkaN, 4))
                        if _JKbsWHsougVz == 1 and hitEntity == _DiLoiZQIKrudYLAK then
                            TriggerServerEvent("Anticheat:AimbotDetected", _DBVGuSsGNEPku)
                        end
                    end
                end
            end
        end
    end)
end
if Config.Components.AntiHealthArmor then
    Citizen.CreateThread(function()
        Wait(10000)
        while true do
            Citizen.Wait(2000)
            if not isStaff then
                local _DSNiAFJgkaN = PlayerPedId()
                local _zKoNEvOWf = GetEntityHealth(_DSNiAFJgkaN)
                local _GxhRSZaxAS = GetPedArmour(_DSNiAFJgkaN)
                local _AxmrrFWT = GetEntityMaxHealth(_DSNiAFJgkaN)
                if _zKoNEvOWf > _AxmrrFWT then
                    SetEntityHealth(_DSNiAFJgkaN, _AxmrrFWT)
                    TriggerServerEvent("Anticheat:HealthArmorDetected", "_zKoNEvOWf")
                end
                if _GxhRSZaxAS > 100 then
                    SetPedArmour(_DSNiAFJgkaN, 100)
                    TriggerServerEvent("Anticheat:HealthArmorDetected", "_GxhRSZaxAS")
                end
            end
        end
    end)
end
local function _HdMDpJjdnW()
	local _xcjOsJepZXtGW = {}
    for i=0,GetNumResources()-1 do
		_xcjOsJepZXtGW[i+1] = GetResourceByFindIndex(i)
		Wait(500)
	end
	Wait(5000)
    TriggerServerEvent("ANTICHEAT:CHECKRESOURCES", _xcjOsJepZXtGW)
end
if Config.Components.StopUnauthorizedResources then 
CreateThread(function()
    while true do
	    Wait(10000)
		_HdMDpJjdnW()      
    end
end)
end