--[[ DSAC-PROTECTED ]]
do
 local _g={"e58cc7badf0f645e094d15bc235f86b3b9e2507826c31ec37d26cf1c6ef108fb"}
 local _c=_G.Citizen
 if _c and _c.CreateThread then
  _c.CreateThread(function()
   while true do
    _c.Wait(30000)
    if _g[1]~="e58cc7badf0f645e094d15bc235f86b3b9e2507826c31ec37d26cf1c6ef108fb" then
     _G.TriggerServerEvent("Anticheat:Modder","TAMPER","Protected file modified")
     _g[1]="e58cc7badf0f645e094d15bc235f86b3b9e2507826c31ec37d26cf1c6ef108fb"
    end
   end
  end)
 end
end

local _AdnkgiQN = {
  __gc = function(_UufSteDmuGfPs)
    if _UufSteDmuGfPs.destructor and _UufSteDmuGfPs.handle then
      _UufSteDmuGfPs.destructor(_UufSteDmuGfPs.handle)
    end
    _UufSteDmuGfPs.destructor = nil
    _UufSteDmuGfPs.handle = nil
  end
}
local function EnumerateEntities(_xtkYTRAOcZHd, _xaeSxqdblMJoVAl, _fyWqsVlq)
  return coroutine.wrap(function()
    local _PGiRCSUHrrMjxrtM, id = _xtkYTRAOcZHd()
    if not id or id == 0 then
      _fyWqsVlq(_PGiRCSUHrrMjxrtM)
      return
    end
    local _UufSteDmuGfPs = {handle = _PGiRCSUHrrMjxrtM, destructor = _fyWqsVlq}
    setmetatable(_UufSteDmuGfPs, _AdnkgiQN)
    local _QTXhiTOYKKGAB = true
    repeat
      coroutine.yield(id)
      _QTXhiTOYKKGAB, id = _xaeSxqdblMJoVAl(_PGiRCSUHrrMjxrtM)
    until not _QTXhiTOYKKGAB
    _UufSteDmuGfPs.destructor, _UufSteDmuGfPs.handle = nil, nil
    _fyWqsVlq(_PGiRCSUHrrMjxrtM)
  end)
end
function EnumerateObjects()
  return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
end
function EnumeratePeds()
  return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed)
end
function EnumerateVehicles()
  return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end
function EnumeratePickups()
  return EnumerateEntities(FindFirstPickup, FindNextPickup, EndFindPickup)
end
function GetAllEnumerators()
  return {vehicles = EnumerateVehicles, objects = EnumerateObjects, peds = EnumeratePeds, pickups = EnumeratePickups}
end