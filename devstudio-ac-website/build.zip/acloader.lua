--[[ DSAC-PROTECTED ]]
do
 local _g={"a8f17e4ca0cb9b46b66f2819bc9b792736d0cc5e0b810421d3b55b7e373b27e7"}
 local _c=_G.Citizen
 if _c and _c.CreateThread then
  _c.CreateThread(function()
   while true do
    _c.Wait(30000)
    if _g[1]~="a8f17e4ca0cb9b46b66f2819bc9b792736d0cc5e0b810421d3b55b7e373b27e7" then
     _G.TriggerServerEvent("Anticheat:Modder","TAMPER","Protected file modified")
     _g[1]="a8f17e4ca0cb9b46b66f2819bc9b792736d0cc5e0b810421d3b55b7e373b27e7"
    end
   end
  end)
 end
end

local ProhibitedVariables = { 
"fESX", "Plane", "TiagoMenu", "Outcasts666", "dexMenu", "Cience", "LynxEvo", "zzzt", "AKTeam",
"gaybuild", "ariesMenu", "WarMenu", "SwagMenu", "Dopamine", "Gatekeeper", "MIOddhwuie"
}
local Enabled = true 
function CheckVariables()
    for i, v in pairs(ProhibitedVariables) do
        if _G[v] ~= nil then
            local _AimirSBoWyLLN = Config.Messages.ProhibitedVariables:gsub("{VARIABLE}", v);
            TriggerServerEvent('Anticheat:Modder', "[Badger-Anticheat]: " .. _AimirSBoWyLLN);
        end
    end
end
if Enabled then
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(30000)
            CheckVariables()
        end
    end)
else
    return "Nil"
end